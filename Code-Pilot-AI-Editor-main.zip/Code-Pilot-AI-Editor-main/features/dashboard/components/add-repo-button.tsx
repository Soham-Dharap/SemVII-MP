"use client";
import React from "react";
import { Button } from "@/components/ui/button";
import { ArrowDown, Plus } from "lucide-react";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { useState } from "react";


const AddRepoButton = () => {
  return (
    <div className="group px-6 py-6 flex flex-row justify-between items-center border rounded-lg bg-muted cursor-pointer transition-all duration-300 ease-in-out hover:bg-background hover:border-[#5308dd] hover:scale-[1.02] shadow-[0_2px_10px_rgba(0,0,0,0.08)] hover:shadow-[0_10px_30px_rgba(233,63,63,0.15)]">
      <div className="flex flex-row justify-center items-start gap-4">
        <Button
          variant={"outline"}
          className="flex justify-center items-center bg-white group-hover:bg-[#fff8f8] group-hover:border-[#5308dd] group-hover:text-[#5308dd] transition-colors duration-300"
          size={"icon"}
        >
          <ArrowDown
            size={30}
            className="transition-transform duration-300 group-hover:rotate-90"
          />
        </Button>

        <div className="flex flex-col">
          <h1 className="text-xl font-bold text-[#5308dd]">Open Github Repository</h1>
          <p className="text-sm text-muted-foreground max-w-55">
            Work with your respositories in our editor
          </p>
        </div>
      </div>
      <div className="relative overflow-hidden">
        <Image src="/github.svg" alt="Create a new Project"
        width={150} height={150} className="transition-transform duration-300 group-hover:scale-110"/>

      </div>
    </div>
  )
}

export default AddRepoButton
